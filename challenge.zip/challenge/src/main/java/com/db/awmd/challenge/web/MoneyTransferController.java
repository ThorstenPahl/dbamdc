package com.db.awmd.challenge.web;

import java.io.IOException;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.domain.MoneyTransfer;
import com.db.awmd.challenge.repository.AccountsRepository;
import com.db.awmd.challenge.service.NotificationService;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v1/transferMoney")
@Slf4j
public class MoneyTransferController {

	@Getter
	private final AccountsRepository accountsRepository;

	@Getter
	NotificationService notificationService;

	@Autowired
	public MoneyTransferController(AccountsRepository accountsRepository, NotificationService notificationService) {
		this.accountsRepository = accountsRepository;
		this.notificationService = notificationService;
	}

	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public void transferMoney(@RequestBody @Valid MoneyTransfer transfer) {

		Account accFrom = accountsRepository.getAccount(transfer.getAccountFrom());
		if (null == accFrom) {
			throw new IllegalArgumentException("error.accountFrom");
		}
		Account accTo = accountsRepository.getAccount(transfer.getAccountTo());
		if (null == accTo) {
			throw new IllegalArgumentException("error.accountTo");
		}

		log.info("transfer.getAmount() " + transfer.getAmount());
		log.info("accFrom.Balance " + accFrom.getBalance());
		log.info("accto.Balance " + accTo.getBalance());

		Lock lock = new ReentrantLock();
		lock.lock();

		try {

			if (accFrom.getBalance().compareTo(transfer.getAmount()) < 1) {
				throw new IllegalArgumentException("error.amount");
			}
			accFrom.setBalance(accFrom.getBalance().subtract(transfer.getAmount()));
			accTo.setBalance(accTo.getBalance().add(transfer.getAmount()));
			notificationService.notifyAboutTransfer(accFrom,
					"transferred amount ".concat(transfer.getAmount().toString()));
			notificationService.notifyAboutTransfer(accFrom,
					"received amount ".concat(transfer.getAmount().toString()));
		} finally {
			lock.unlock();
		}
	}

	@ExceptionHandler
	void handleIllegalArgumentException(IllegalArgumentException e, HttpServletResponse response) throws IOException {
		log.error("request failed because {}", e.getMessage(), e);
		response.sendError(HttpStatus.BAD_REQUEST.value());

	}

}
