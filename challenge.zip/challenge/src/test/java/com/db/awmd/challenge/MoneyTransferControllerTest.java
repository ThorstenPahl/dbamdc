package com.db.awmd.challenge;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.service.AccountsService;
import com.db.awmd.challenge.service.NotificationService;
import com.db.awmd.challenge.web.MoneyTransferController;

import java.math.BigDecimal;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest
@WebAppConfiguration
public class MoneyTransferControllerTest {

  private MockMvc mockMvc;

  @Autowired
  private AccountsService accountsService;

  @Autowired
  private MoneyTransferController moneyTransferService;

  @Autowired
  private WebApplicationContext webApplicationContext;
  
  @MockBean
  private NotificationService notificationService;

  @Before
  public void prepareMockMvc() {
    this.mockMvc = webAppContextSetup(this.webApplicationContext).build();

    // Reset the existing accounts before each test.
    accountsService.getAccountsRepository().clearAccounts();
  }

  @Test
  public void transferAmount500() throws Exception {
    this.mockMvc.perform(post("/v1/accounts").contentType(MediaType.APPLICATION_JSON)
      .content("{\"accountId\":\"Id-123\",\"balance\":1000}")).andExpect(status().isCreated());
    this.mockMvc.perform(post("/v1/accounts").contentType(MediaType.APPLICATION_JSON)
    	      .content("{\"accountId\":\"Id-124\",\"balance\":1000}")).andExpect(status().isCreated());
    this.mockMvc.perform(post("/v1/transferMoney").contentType(MediaType.APPLICATION_JSON)
  	      .content("{\"accountFrom\":\"Id-123\",\"accountTo\":\"Id-124\",\"amount\":\"500\"}")).andExpect(status().is2xxSuccessful());

    Account account = accountsService.getAccount("Id-123");
    assertThat(account.getAccountId()).isEqualTo("Id-123");
    assertThat(account.getBalance()).isEqualByComparingTo("500");
  }

  @Test
  public void senderHasnotEnoughMony() throws Exception {
    this.mockMvc.perform(post("/v1/accounts").contentType(MediaType.APPLICATION_JSON)
      .content("{\"accountId\":\"Id-123\",\"balance\":1000}")).andExpect(status().isCreated());
    this.mockMvc.perform(post("/v1/accounts").contentType(MediaType.APPLICATION_JSON)
    	      .content("{\"accountId\":\"Id-124\",\"balance\":1000}")).andExpect(status().isCreated());
    this.mockMvc.perform(post("/v1/transferMoney").contentType(MediaType.APPLICATION_JSON)
  	      .content("{\"accountFrom\":\"Id-123\",\"accountTo\":\"Id-124\",\"amount\":\"1500\"}")).andExpect(status().is4xxClientError());
  }

  @Test
  public void senderAccountUnknown() throws Exception {
    this.mockMvc.perform(post("/v1/accounts").contentType(MediaType.APPLICATION_JSON)
    	      .content("{\"accountId\":\"Id-124\",\"balance\":1000}")).andExpect(status().isCreated());
    this.mockMvc.perform(post("/v1/transferMoney").contentType(MediaType.APPLICATION_JSON)
  	      .content("{\"accountFrom\":\"Id-123\",\"accountTo\":\"Id-124\",\"amount\":\"1500\"}")).andExpect(status().is4xxClientError());
  }

  @Test
  public void receiverAccountUnknown() throws Exception {
    this.mockMvc.perform(post("/v1/accounts").contentType(MediaType.APPLICATION_JSON)
      .content("{\"accountId\":\"Id-123\",\"balance\":1000}")).andExpect(status().isCreated());
    this.mockMvc.perform(post("/v1/transferMoney").contentType(MediaType.APPLICATION_JSON)
  	      .content("{\"accountFrom\":\"Id-123\",\"accountTo\":\"Id-124\",\"amount\":\"500\"}")).andExpect(status().is4xxClientError());
  }

}
